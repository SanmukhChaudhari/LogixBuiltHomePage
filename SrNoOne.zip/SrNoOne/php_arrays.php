<!DOCTYPE html>
<html>
<head>
	<title>Arrays in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>PHP Arrays</h4>
		<ol>
			<li>Indexed array : Arrays with a numeric index<br></li>

			Example : <br><br>
			Code : <br>
			$names = array("Sanmukh","Vignesh","Ayush");<br>
			print_r($names);
			<br><br>
			Output : <br>
			<?php 
			$names = array("Sanmukh","Vignesh","Ayush");
			print_r($names);
			?>

			<br><br>

			<li>Associative arrays : Associative arrays are arrays that use named keys that you assign to them.<br></li>

			Example : <br><br>
			Code : <br>
			$names = array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851);<br>
			print_r($names);
			<br><br>
			Output : <br>
			<?php 
			$names = array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851);
			print_r($names);
			?>


			<br><br>

			<li>Multidiamensional arrays : A multidimensional array is an array containing one or more arrays.<br></li>

			Example : <br><br>
			Code : <br>
			$names = array(<br>
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),<br>
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),<br>
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)<br>
					);<br>
			print_r($names);
			<br><br>
			Output : <br>
			<?php 
			$names = array(
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)
					);
			print_r($names);
			?>
		
			<br><br>

			<li>For Loop : It is used for iteration.<br><br>

			Example : <br><br>
			Code : <br>
			$names = array(<br>
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),<br>
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),<br>
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)<br>
					);<br>
			for ($i=0; $i < count($names); $i++) { <br>
				print_r($names[$i]);<br>
				echo "&ltbr&gt";<br>
			}
			<br><br>
			Output : <br>
			<?php 
			$names = array(
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)
					);
			for ($i=0; $i < count($names); $i++) { 
				print_r($names[$i]);echo "<br>";
			}
			?>

			<br><br>
			<li>Foreach Loop : It is also used for iteration.<br><br>

			Example : <br><br>
			Code : <br>
			$names = array(<br>
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),<br>
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),<br>
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)<br>
					);<br>
			foreach ($names as $name) { <br>
				print_r($name);<br>
				echo "&ltbr&gt";<br>
			}
			<br><br>
			Output : <br>
			<?php 
			$names = array(
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)
					);
			foreach ($names as $name) {
				print_r($name);echo "<br>";
			}
			?>

			<br><br>
			<li>While Loop : It is also used for iteration.But it will check first conditoion and than if condition is true than it will execute block of code otherwise it will terminated.<br><br>

			Example : <br><br>
			Code : <br>
			$names = array(<br>
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),<br>
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),<br>
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)<br>
					);<br>
			$i=0;
			<br>
			while ($i< count($names))<br> { <br>
				print_r($names[$i]);<br>echo "&ltbr&gt";<br>
				$i++;
			}
			
			<br><br>
			Output : <br>
			<?php 
			$names = array(
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)
					);
			$i=0;
			while ($i<count($names)) {
				print_r($names[$i]);echo "<br>";
				$i++;
			}
			?>




			<br><br>
			<li>Do While Loop : It is also used for iteration.But it will execute block of statement at least one time and than it will check first conditoion and than if condition is true than it will execute block of code otherwise it will terminated.<br><br>

			Example : <br><br>
			Code : <br>
			$names = array(<br>
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),<br>
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),<br>
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)<br>
					);<br>
			$i=0;
		
			<br> do{ <br>
				print_r($names[$i]);<br>echo "&ltbr&gt";<br>
				$i++;
			}<br>
			while ($i< count($names));
			
			<br><br>
			Output : <br>
			<?php 
			$names = array(
						array("name"=>"Sanmukh","age"=>20,"contact_number"=>8154993851),
						array("name"=>"Vignesh","age"=>21,"contact_number"=>8154993852),
						array("name"=>"Ayush","age"=>22,"contact_number"=>8154993853)
					);
			$i=0;
			do{
				print_r($names[$i]);echo "<br>";
				$i++;
			}
			while ($i<count($names));
			?>
		
		</ol>
		<h4>PHP Object</h4>
		<ol>
			<li>Creation of object : </li>
			<br>
			Example : 
			<br><br>
			Code :
			<br><br>
			class Student<br>
			{<br>
				public $name;<br>
				public $marks;<br>
				
			};<br>
			$s1 = new Student();<br>
			$s1->name = "Sanmukh";<br>
			$s1->marks = 44;<br>
			<br>
			print_r($s1);<br>
			echo "&ltbr&gt";<br>
			$s1->name ="Vignesh";<br>
			$s1->marks = 75;<br>
			<br>
			print_r($s1);<br>

			<br>
			Output :
			<br><br>
			<?php
			class Student
			{
				public $name;
				public $marks;
			
			};
			$s1 = new Student();
			$s1->name = "Sanmukh";
			$s1->marks = 44;
			print_r($s1);
			echo "<br>";
			$s1->name ="Vignesh";
			$s1->marks = 75;
			
			print_r($s1);

			?>
		</ol>

</body>
</html>
 