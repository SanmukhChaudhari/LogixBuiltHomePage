
					
<!DOCTYPE html>
<html>
<head>
	<title>Reverse Number in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Reverse Number</h4>
		<ol>
			<li>Write a PHP program to find the reverse of a number.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter Number : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Result</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						
						getResult($num);
					}
					function getResult($num)
					{

						$sum = 0;
						while((int)$num != 0)
						{
							$rem = $num % 10;
							$sum = $sum * 10 + $rem;	
							$num = $num / 10;
						
						}
						echo $sum;
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 