
					
<!DOCTYPE html>
<html>
<head>
	<title>Check Prime or Not in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Check Prime or Not</h4>
		<ol>
			<li>To check whether a number is Prime or not.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter Number : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Result</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						isPrime($num);
						
					}
					function isPrime($num)
					{
						for($i = 2; $i <= $num-1; $i++) 
						{
	     					if ($num % $i == 0) 
	     					{  
							    $bool=True;  
							}  	
						}
						if(isset($bool) && $bool==True)
						{
							echo "Not Prime";
						}
						else
						{
							echo "Prime";
						}
	
					
						
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 