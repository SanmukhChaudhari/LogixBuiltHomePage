
					
<!DOCTYPE html>
<html>
<head>
	<title>Smallest Number From Array in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Find Smallest Number From Array</h4>
		<ol>
			<li>Write a Program for finding the Smallest number in 
an array.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter Numbers(Separated By ,[Comma]) : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Smallest</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						printArray($num);
						
					}
					function printArray($num)
					{
						
						$a = array();
						$k=0;

						$a = explode(',', $num);
						echo "Your Array Is : ";print_r($a);
						echo "<br>";
						$min = $a[0]; 
						for($i=0;$i<count($a);$i++)
						{
							if($a[$i] < $min)
							{
								$min = $a[$i];
							}
						}
						echo "Smallest Number is : ".$min;
						
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 