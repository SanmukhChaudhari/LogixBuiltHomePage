<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Home Page | Bootstrap</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity=
	"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<link rel="stylesheet" href="assets/swiper-bundle.min.css">

</head>
<style type="text/css">
	a.nav-link:hover {
    color: #993408 !important;
	}
	.menu-a{
		font-size: 15px;
		font-family: Tohama;
	}
	.sidemenu{
		font-size: 17px;
		font-family: Georgia ;
		color: #993408 !important;

	}
	.sm-active
	{
		background-image: url('Slices/sidebar-title-bg.png') !important;
		color: white;

	}
	.img-heading
	{
		margin-top: 5px;
		font-size: 15px;
		font-family: Georgia;
		color:#000;
	}
	.img-content
	{
		
		font-size: 13px;
		font-family: Tohama;
		color:#333;
	}
	.img-container{
		border: 1px solid #949599;
	}

	.img-container-body{
		border-top: 1px solid #949599;
		border-right: 1px solid #949599;

		border-bottom: 1px solid #949599;
	}
	.side-a{
		padding-top: 10px;
		padding-bottom: 10px;
		padding-left: 20px;
		color:#993408 !important;
		margin-bottom: 5px !important;
		margin-top: 5px !important;
		font-family: Georgia !important;
	}
	.side-a:hover{
		color:white !important;
		text-decoration: none;
		clip-path: polygon(0 0,90% 0%, 100% 50%, 90% 100%, 0 100%);
		background-color: #993408 !important;
		
	} .side-a.active{ clip-path: polygon(0 0,90% 0%, 100% 50%, 90% 100%, 0 100%);
background-color: #993408 !important; color:white !important;
		
}

	}
	.side-a.active aero{
	
		background-color:#993408 !important;
 		width: 0;
	height: 0;
	}
	.footer-head
	{
		font-family: Tahoma;
		font-size: 15px;
		color:#888;
	}	
	hr{
		border-top: 2px dashed grey;
	}
	.footer-container
	{
		padding-top: 15px;
	}
	.footer-img
	{
		padding-top:10px !important;
		padding-bottom: 10px !important;
	}
	.footer-icons > li {
		display: flex !important;

		padding-bottom: 5px;
		padding-top: 5px;
	}
	.icon-names{
		padding-left: 10px !important;
	}
	.icon-names:hover{

		padding-left: 10px !important;
	}
	
	.first-img-text:hover img
	{
		content: url('Slices/logo1.png');

	}
	.first-img-text:hover .first-p
	{
		color:#556fa8;
	}
	.second-img-text:hover img
	{
		content: url('Slices/logo2.png');

	}
	.second-img-text:hover .second-p
	{
		color:#34ccfd;
	}
	.third-img-text:hover img
	{
		content: url('Slices/logo3.png');

	}
	.third-img-text:hover .third-p
	{
		color:#006f9f;
	}
	.fourth-img-text:hover img
	{
		content: url('Slices/logo4.png');

	}
	.fourth-img-text:hover .fourth-p
	{
		color:#ff9b00;
	}
	.footer-menu > li
	{
		
		margin-right: 10px;
	}
	.footer-menu > li > a
	{
		color: #666 !important;
		font-style: Tahoma;
		font-size: 13px; 
		font-weight: bold;
		
	}
	.footer-news > li{
		margin-left: -15px !important;
	}
	.footer-menu > li > a : hover
	{
		color: #993408 !important;		
	}
	p:hover{
	color: #993408 !important;			
	}
	.footer-text
	{
		margin-top: -2px !important;
		color: #999 !important;
		font-style: Tahoma;
		font-size: 13px; 
	}
	.top-right {
  position: absolute;
  top: 10px;
  right: 10px;
  left: 10px;
  bottom: 10px;
}
.swiper-container {
      width: 100%;
      height: 341px;
    }

    .swiper-slide {

      font-size: 18px;
      background: black !important;
      opacity: 0.6;
      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;
    }
   	.img-container {
 
    position: relative;
	}
	
	.slide-content
	{
		font-family: Georgia !important;
		color: #ccc;
		font-size: 14px;	
	}
	.slide-heading{
		font-family: Georgia !important;
		color: #fff;
		font-size: 24px;
	}
	
	.swiper-pagination-bullet{
		background-color: white !important;
		opacity: 1;
	}
	.swiper-pagination-bullet-active{
		opacity: 1;
		background-color: #993408 !important;
	}
	.p-3 > li:hover
	{
		color: #993408 !important;		
	}
	.footer-logo
		{
			text-align: right !important;
		}
	@media (max-width:2048px) {
	  .swiper-container {
	    width: 100%;
	    height: 340px;
		}
	}
	@media (max-width:1024px) {
	  .swiper-container {
	    width: 100%;
	    height: 284px;
		}
		
	}
	@media (max-width: 768px)
	{
		.swiper-container {
	    width: 100%;
	    height: 209px;
		}
		.swiper-slide {
	    padding-top: 105px;
		}
		.navbar-nav {
			display: block;
			}
		

	}
	@media (max-width: 425px)
	{
		.swiper-container {
	    width: 100%;
    	height: 117px;
    	}
		.swiper-slide {
   		 padding-top: 62px !important;
		}
		.swiper-pagination
		{
			padding-top: 10% !important;
		}
		.img-container-body{
		border-left: 1px solid #949599;
		}
		.text-right
		{
			text-align: center !important;
		}
		.footer-logo
		{
			text-align: center !important;
		}
	}
	@media (max-width: 375px)
	{
		.swiper-container {
	    width: 100%;
    	height: 101px;
    	}
		.swiper-slide {
   		 padding-top: 95px !important;
		}
		.swiper-pagination
		{
			padding-top: 10% !important;
		}
		.footer-logo
		{
			text-align: center !important;
		}
	}
	@media (max-width: 375px)
	{
		.swiper-container {
	    width: 100%;
    	height: 85px;
    	}
		.swiper-slide {
   		 padding-top: 117px !important;
		}
		.swiper-pagination
		{
			padding-top: 10% !important;
		}
	}	

</style>
<body>
	<!--Header menu start -->
	<header>
			<div class="container">
			  
			<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-image:url('Slices/header-bg.jpg')">
				  <a class="navbar-brand" href="#"><img src="Slices/logo.png" style="height:50px;"></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  			</button>
				  <div class="collapse navbar-collapse" id="navbarNavDropdown">
				    <ul class="navbar-nav ml-auto">
				      <li class="nav-item black">
				        <a class="nav-link active" href="#">Home</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">News</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Gallery</a>
				      </li>
				      	<li class="nav-item">
				        <a class="nav-link active" href="#">Pages</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Layouts</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Features</a>
				      </li>
				      	<li class="nav-item">
				        <a class="nav-link active" href="#">Blog</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Contact</a>
				      </li>
				    </ul>
				  </div>
				</nav>
			</div>		
	</header>
	<!--Header menu end-->

	<!--Slider image start -->
	
	<div class="container-fluid p-0" style="background-color: #949599;">
		<div class="container" style="padding: 15px white;padding-top: 10px;padding-bottom: 10px;">
			
			<div class="row">
				<div class="col-sm-12">
			    	<div class="img-container">
			        	<img src="Slices/Slider_img.jpg" style="border:11px solid white;" class="w-100">
			        	<div class="row top-right" style="position: absolute;">
							<div class="col-md-8">
								
							</div>			     
							<div class="col-md-4">
						
		                        <div class="swiper-container">
							    	<div class="swiper-wrapper" >
							      		<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline1</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side.good aftyernoon This is from my side.This is from my side.This is from my side.   good morning.
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my 
							      				</div>
							      					
							      			</div>
										</div>
										<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline2</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side. good morning.
							      				</div>
							      					
							      			</div>
										</div>
										<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline3</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side. good morning.
							      				</div>
							      					
							      			</div>
										</div>
										<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline4</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side. good morning.
							      				</div>
							      					
							      			</div>
										</div>
									
							    	</div>
							    	<div class="swiper-pagination" style="border-left: 1px solid white;padding-top:40%;height:100%;padding-left: 5px;">
							    		
							    	</div>
							    	<div class="swiper-scrollbar"></div>
							  	</div>		
                  			</div>
						</div>  <!--End row--> 		
			       	</div>
				</div>  
			</div>
		</div>
	</div>
			
	<!--Slider image end -->

	<!--Tabs/Pills part start -->
	
	<div class="container my-3 ">
	<div class="row " style="padding-left: 15px;padding-right: 15px;display: flex;">	
			<div class="col col-md-3 img-container p-0" style="background-color: #ebebeb;">
				<nav class="nav nav-pills flex-column" >
			        <a href="#first" class="nav-item  side-a active" data-toggle="tab">
			            FINDINGS
			        </a>

			        <a href="#second" class="nav-item  side-a" data-toggle="tab">
			            PROMOTIONAL ACTIVITIES
			        </a>
			        <a href="#third" class="nav-item  side-a" data-toggle="tab">
			            ENVIRONMENT
			        </a>
			    </nav> 
			</div>

			<div class="col-md-9 img-container-body">
				
				<div class="tab-content ">
					
				<div class="tab-pane active" id="first">

					<div class="row mt-3 mb-3">
						<div class="col-md-4">
							<img src="Slices/img1.jpg" class="w-100">
							<div class="img-heading">
							111Aldus PageMaker including versions of Lorem Ipsum. 
						</div>
						<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>

						</div>
						<div class="col-md-4">
							<img src="Slices/img2.jpg" class="w-100">
							<div class="img-heading">
							Many desktop publishing packages and web pages. 
							</div>
							<div class="img-content">
							It is a long established fact that a reader will be distracted by the readable content.	
							</div>


						</div>
						<div class="col-md-4">
							<img src="Slices/img3.jpg" class="w-100">
							<div class="img-heading">
							Aldus PageMaker including versions of Lorem Ipsum. 
							</div>
							<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="second">

					<div class="row mt-3 mb-3">
						<div class="col-md-4">
							<img src="Slices/img1.jpg" class="w-100">
							<div class="img-heading">
							222Aldus PageMaker including versions of Lorem Ipsum. 
						</div>
						<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>

						</div>
						<div class="col-md-4">
							<img src="Slices/img2.jpg" class="w-100">
							<div class="img-heading">
							Many desktop publishing packages and web pages. 
							</div>
							<div class="img-content">
							It is a long established fact that a reader will be distracted by the readable content.	
							</div>


						</div>
						<div class="col-md-4">
							<img src="Slices/img3.jpg" class="w-100">
							<div class="img-heading">
							Aldus PageMaker including versions of Lorem Ipsum. 
							</div>
							<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="third">

					<div class="row mt-3 mb-3">
						<div class="col-md-4">
							<img src="Slices/img1.jpg" class="w-100">
							<div class="img-heading">
							333Aldus PageMaker including versions of Lorem Ipsum. 
						</div>
						<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>

						</div>
						<div class="col-md-4">
							<img src="Slices/img2.jpg" class="w-100">
							<div class="img-heading">
							Many desktop publishing packages and web pages. 
							</div>
							<div class="img-content">
							It is a long established fact that a reader will be distracted by the readable content.	
							</div>


						</div>
						<div class="col-md-4">
							<img src="Slices/img3.jpg" class="w-100">
							<div class="img-heading">
							Aldus PageMaker including versions of Lorem Ipsum. 
							</div>
							<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>
						</div>
					</div>
				</div>
			</div>

				
				
			</div>
			


		</div>
	</div>
	<!--Tabs/Pills part end -->

	<!--Footer start-->
	<footer>
		<div class="container-fluid" style="background-color: #f8f8f8;border-top: 1px solid #949599;border-bottom: 1px solid #949599;">
			<div class="container footer-container">
			
					<div class="row">
						<div class="col-lg-3 footer-head"><b>LATEST NEWS</b>
							<hr/>
							<ul class="p-3 footer-news" >
								<li style="display: flex;">
									<div style="margin-right: 10px;">
										<img  src="Slices/sidebar-bullet.jpg">
									</div>
									<div>
										<p>Many desktop publishing packages and web page</p>
									</div>
								</li>
								<li style="display: flex;">
									<div style="margin-right: 10px;">
										<img  src="Slices/sidebar-bullet.jpg">
									</div>
									<div>
										<p>Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.</p>
									</div>
								</li>
								<li style="display: flex;">
									<div style="margin-right: 10px;">
										<img  src="Slices/sidebar-bullet.jpg">
									</div>
									<div>
										<p>It is a long established fact that a reader will be distracted by the readable content.</p>
									</div>
								</li>
							</ul>

						</div>
						<div class="col-lg-3 footer-head"><b>RECENT PROJECTS</b>
							<hr/>
							<ul class="p-3" style="list-style: none;padding-left:0px !important;">
								<li><img src="Slices/recent-pro-1.jpg" class="footer-img"></li>
								<li><img src="Slices/recent-pro-2.jpg" class="footer-img"></li>
								<li><img src="Slices/recent-pro-3.jpg" class="footer-img"></li>
							</ul>
						</div>
						<div class="col-lg-3 footer-head"><b>STAY IN TOUCH</b>
							<hr/>
							<ul class="p-3 footer-icons" style="list-style: none;padding-left:0px !important;">
								<li>
									<div class="first-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo5.png" id="f-icon1">
										</div>		
										<div class="icon-names first-p">Facebook
										</div>
									</div>
								</li>
								<li>
									<div class="second-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo6.png" id="f-icon2">
										</div>		
										<div class="icon-names second-p">Twitter
										</div>
									</div>
								</li>
								<li>
									<div class="third-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo7.png" id="f-icon3">
										</div>		
										<div class="icon-names third-p">Linked In
										</div>
									</div>
								</li>
								<li>
									<div class="fourth-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo8.png" id="f-icon4">
										</div>		
										<div class="icon-names fourth-p">RSS
										</div>
									</div>
								</li>
								
							</ul>
						</div>
						<div class="col-lg-3 footer-head"><b>SECURITY & PRIVACY</b>
							<hr/>
							<ul class="p-3" style="list-style: none;padding-left:0px !important;">
								<li>Security</li>
								<li>Privacy Policy</li>
								<li>Terms of Service</li>
							</ul>
						</div>
					</div>		
			</div>
		
		</div>

		<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<ul class="navbar-nav ml-auto list-group-horizontal p-1 footer-menu">
					      <li class="nav-item	">
					        <a class="nav-link" href="#">Home</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">News</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Gallery</a>
					      </li>
					      	<li class="nav-item">
					        <a class="nav-link" href="#">Pages</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Layouts</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Features</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Blog</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Contact</a>
					      </li>
						</ul>
						<div class="footer-text" style="float: left;">
						&#169; 2011 rtPanel. All Rights Reserved. Designed by rtCamp.
						</div>

					</div>
					<div class="col-sm-6 footer-logo" style="margin-top: 10px;">
							<img src="Slices/footer-logo.png" ;>
						
					</div>
				</div>
			</div>
	</footer>
	<!--Footer end -->
	<script src="assets/swiper-bundle.min.js"></script>
<script>
		var swiper = new Swiper('.swiper-container', {
      direction: 'vertical',
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
  	 	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-top',
  	},
    });
	</script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>
</html>