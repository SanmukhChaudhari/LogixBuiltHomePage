<?php
include "database.php";

$query = "SELECT * FROM student";
$result = mysqli_query($con,$query);

?>

<!DOCTYPE html>
<html>
<head>
	<title>SQL Functions</title>
</head>
<body>
	<h3>30 MSQL functions with small demo for each like sum, count with demo.</h3>
	
	Following table used in the example : 
	<br><br>
	<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Name</th>
			<th>Marks</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($result))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['marks']; ?></td>
		</tr>
	<?php }
	?>

	</table>
	<ol>
		<li>sum() : This function is used to find the sum of the given field.</li>
		<br>
		Query : SELECT sum(marks) FROM student

		<br>
		Output : 

		<?php
		$query = "SELECT sum(marks) FROM student";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['sum(marks)'];
		?>
		<br><br>
		<li>count() : This function is used to find the total no of rows.</li>
		<br>
		Query : SELECT count(*) FROM student

		<br>
		Output : 

		<?php
		$query = "SELECT count(*) FROM student";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['count(*)'];
		?>

		<br><br>
		<li>avg() : This function is used to find the average of given field.</li>
		<br>
		Query : SELECT avg(marks) FROM student

		<br>
		Output : 

		<?php
		$query = "SELECT avg(marks) FROM student";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['avg(marks)'];
		?>

		<br><br>
		<li>min() : This function is used to find the minimum of given field.</li>
		<br>
		Query : SELECT min(marks) FROM student

		<br>
		Output : 

		<?php
		$query = "SELECT min(marks) FROM student";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['min(marks)'];
		?>

		<br><br>
		<li>abs() : This function is used to find the absolute of given value.</li>
		<br>
		Query : SELECT abs(-100);

		<br>
		Output : 

		<?php
		$query = "SELECT abs(-100)";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['abs(-100)'];
		?>

		<br><br>
		<li>floor() : This function is used to find the floor of given value.</li>
		<br>
		Query : SELECT floor(1.45);

		<br>
		Output : 

		<?php
		$query = "SELECT floor(1.45)";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['floor(1.45)'];
		?>

		<br><br>
		<li>ceiling() : This function is used to find the ceiling of given value.</li>
		<br>
		Query : SELECT ceiling(1.45);

		<br>
		Output : 

		<?php
		$query = "SELECT ceiling(1.45)";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ceiling(1.45)'];
		?>

		
		<br><br>
		<li>trim() : This function is used to trim the given string.</li>
		<br>
		Query : SELECT trim('Sanmukh&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspChaudhari') AS trimmed;

		<br>
		Output : 

		<?php
		$query = "SELECT trim('Sanmukh     Chaudhari') AS trimmed";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['trimmed'];
		?>
		

		<br><br>
		<li>substring() : This function is used to find the substring of the given string.</li>
		<br>
		Query : SELECT SUBSTRING('Sanmukh Chaudhari', 5, 3) AS ExtractString

		<br>
		Output : 

		<?php
		$query = "SELECT SUBSTRING('Sanmukh Chaudhari', 5, 3) AS ExtractString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ExtractString'];
		?>


		<br><br>
		<li>substr() : This function is used to find the substring of the given string.</li>
		<br>
		Query : SELECT SUBSTR('Sanmukh Chaudhari', 5, 3) AS ExtractString

		<br>
		Output : 

		<?php
		$query = "SELECT SUBSTR('Sanmukh Chaudhari', 5, 3) AS ExtractString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ExtractString'];
		?>

		<br><br>
		<li>UCASE() : This function is used to convert the uppercase of the given string.</li>
		<br>
		Query : SELECT UCASE('Sanmukh Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT UCASE('Sanmukh Chaudhari') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>


		<br><br>
		<li>LOWER() : This function is used to convert the uppercase of the given string.</li>
		<br>
		Query : SELECT LOWER('Sanmukh Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT LOWER('SANMUKH CHAUDHARI') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>Length() : This function is used to find the length of the given string.</li>
		<br>
		Query : SELECT length('Sanmukh Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT length('SANMUKH CHAUDHARI') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>ascii() : This function is used to find the ascii code of the given character.</li>
		<br>
		Query : SELECT ascii('S') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT ascii('S') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>char_length() : This function is used to find the lentgh of the given string.</li>
		<br>
		Query : SELECT char_length('Sanmukh Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT char_length('Sanmukh Chaudhari') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>character_length() : This function is used to find the lentgh of the given string.</li>
		<br>
		Query : SELECT character_length('Sanmukh Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT character_length('Sanmukh Chaudhari') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>concat() : This function is used to concatination of the given strings.</li>
		<br>
		Query : SELECT concat('Sanmukh','Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT concat('Sanmukh','Chaudhari') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>concat_ws() : This function is used to concatination of the given strings with specified separator.</li>
		<br>
		Query : SELECT concat_ws('=','Sanmukh','Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT concat_ws('=','Sanmukh','Chaudhari','Dharampor') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>field() : This function is used to find the position of the first parameter string.</li>
		<br>
		Query : SELECT field('Chaudhari','Sanmukh','Chaudhari') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT field('Chaudhari','Sanmukh','Chaudhari','Dharampor') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>


		<br><br>
		<li>find_in_set() : This function is used to find the position of the first parameter string from the set.</li>
		<br>
		Query : SELECT find_in_set('Chaudhari','Sanmukh,Chaudhari,Dharampor') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT find_in_set('Chaudhari','Sanmukh,Chaudhari,Dharampor') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>format() : This function is used to find the round of the given number.</li>
		<br>
		Query : SELECT format(12345.67890,2) AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT format(12345.67890,2) AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>insert() : This function is used to replace the perticular part of the string.</li>
		<br>
		Query : SELECT insert('abxxefghijklmnopqrstuvwxyz',3,2,'cd') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT insert('abxxefghijklmnopqrstuvwxyz',3,2,'cd') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>


		<br><br>
		<li>instr() : This function is used to find the position of the perticular part of the string.</li>
		<br>
		Query : SELECT instr('abxxefghijklmnopqrstuvwxyz','xx') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT instr('abxxefghijklmnopqrstuvwxyz','xx') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>left() : This function is used to extract the perticular part of the string from the left side.</li>
		<br>
		Query : SELECT left('abxxefghijklmnopqrstuvwxyz',3) AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT left('abxxefghijklmnopqrstuvwxyz',3) AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>locate() : This function is used to find the perticular part of the string from the whole string.</li>
		<br>
		Query : SELECT locate('xx','abxxefghijklmnopqrstuvwxyz') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT locate('xx','abxxefghijklmnopqrstuvwxyz') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>lpad() : This function is used to apply padding on the whole string(from left side).</li>
		<br>
		Query : SELECT lpad('abcd',20,'mno') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT lpad('abcd',10,'mno') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>rpad() : This function is used to apply padding on the whole string(from right side).</li>
		<br>
		Query : SELECT rpad('abcd',20,'mno') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT rpad('abcd',10,'mno') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>mid() : This function is used to find substring.</li>
		<br>
		Query : SELECT mid('abcdefghijklmno',3,7) AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT mid('abcdefghijklmno',3,7) AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>position() : This function is used to find position of perticular part of the string.</li>
		<br>
		Query : SELECT position('c' in 'abcdefghijklmno') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT position('c' in 'abcdefghijklmno') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];
		?>

		<br><br>
		<li>replace() : This function is used to find and replace perticular part of the string.</li>
		<br>
		Query : SELECT replace('First Project','First','Second') AS ResultString

		<br>
		Output : 

		<?php
		$query = "SELECT replace('First Project','First','Second') AS ResultString";
		$result = mysqli_query($con,$query);
		$row = mysqli_fetch_assoc($result);
		echo $row['ResultString'];

		?>
	</ol>
</body>
</html>