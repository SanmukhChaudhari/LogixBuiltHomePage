
					
<!DOCTYPE html>
<html>
<head>
	<title>Table of Number in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Generate Table of Number</h4>
		<ol>
			<li>Write a program to find table of a number.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter Number : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Table</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						findTable($num);
						
					}
					function findTable($num)
					{
						for($i = 1; $i <= 10; $i++) 
						{
							echo $num." * ".$i." = ".($i*$num)."<br>";
						}
						
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 