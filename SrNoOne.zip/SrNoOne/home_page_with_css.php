<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Home Page | Bootstrap</title>
	<link rel="stylesheet" href="assets/stylesheet.css">
	<link rel="stylesheet" href="assets/swiper-bundle.min.css">

</head>
<style type="text/css">
	a.nav-link:hover {
    color: #993408 !important;
	}
	.nav-link{
		padding-right: .5rem;
    padding-left: .5rem;
	}

	.menu-a{
		font-size: 15px;
		font-family: Tohama;
	}
	.sidemenu{
		font-size: 17px;
		font-family: Georgia ;
		color: #993408 !important;

	}
	.sm-active
	{
		background-image: url('Slices/sidebar-title-bg.png') !important;
		color: white;

	}
	.img-heading
	{
		margin-top: 5px;
		font-size: 15px;
		font-family: Georgia;
		color:#000;
	}
	.img-content
	{
		
		font-size: 13px;
		font-family: Tohama;
		color:#333;
	}
	.img-container{
		border: 1px solid #949599;
	}

	.img-container-body{
		border-top: 1px solid #949599;
		border-right: 1px solid #949599;

		border-bottom: 1px solid #949599;
	}
	.side-a{
		padding-top: 10px;
		padding-bottom: 10px;
		padding-left: 20px;
		color:#993408 !important;
		margin-bottom: 5px !important;
		margin-top: 5px !important;
		font-family: Georgia !important;
	}
	.side-a:hover{
		color:white !important;
		text-decoration: none;
		clip-path: polygon(0 0,90% 0%, 100% 50%, 90% 100%, 0 100%);
		background-color: #993408 !important;
		
	} 
	.side-a.active{ clip-path: polygon(0 0,90% 0%, 100% 50%, 90% 100%, 0 100%);
	background-color: #993408 !important; color:white !important;
	}

	}
	.side-a.active aero{
	
		background-color:#993408 !important;
 		width: 0;
	height: 0;
	}
	.footer-head
	{
		font-family: Tahoma;
		font-size: 15px;
		color:#888;
	}	
	hr{
		border-top: 2px dashed grey;
	}
	.footer-container
	{
		padding-top: 15px;
	}
	.footer-img
	{
		padding-top:10px !important;
		padding-bottom: 10px !important;
	}
	.footer-icons > li {
		display: flex !important;

		padding-bottom: 5px;
		padding-top: 5px;
	}
	.icon-names{
		padding-left: 10px !important;
	}
	.icon-names:hover{

		padding-left: 10px !important;
	}
	
	.first-img-text:hover img
	{
		content: url('Slices/logo1.png');

	}
	.first-img-text:hover .first-p
	{
		color:#556fa8;
	}
	.second-img-text:hover img
	{
		content: url('Slices/logo2.png');

	}
	.second-img-text:hover .second-p
	{
		color:#34ccfd;
	}
	.third-img-text:hover img
	{
		content: url('Slices/logo3.png');

	}
	.third-img-text:hover .third-p
	{
		color:#006f9f;
	}
	.fourth-img-text:hover img
	{
		content: url('Slices/logo4.png');

	}
	.fourth-img-text:hover .fourth-p
	{
		color:#ff9b00;
	}
	.footer-menu > li
	{
		
		margin-right: 10px;
	}
	.footer-menu > li > a
	{
		color: #666 !important;
		font-style: Tahoma;
		font-size: 13px; 
		font-weight: bold;
		
	}
	.footer-news > li{
		margin-left: -15px !important;
	}
	.footer-menu > li > a : hover
	{
		color: #993408 !important;		
	}
	p:hover{
	color: #993408 !important;			
	}
	.footer-text
	{
		margin-top: -2px !important;
		color: #999 !important;
		font-style: Tahoma;
		font-size: 13px; 
	}
	.top-right {
  position: absolute;
  top: 10px;
  right: 10px;
  left: 10px;
  bottom: 10px;
}
.swiper-container {
      width: 100%;
      height: 341px;
    }

    .swiper-slide {

      font-size: 18px;
      background: black !important;
      opacity: 0.6;
      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;
    }
   	.img-container {
 
    position: relative;
	}
	
	.slide-content
	{
		font-family: Georgia !important;
		color: #ccc;
		font-size: 14px;	
	}
	.slide-heading{
		font-family: Georgia !important;
		color: #fff;
		font-size: 24px;
	}
	
	.swiper-pagination-bullet{
		background-color: white !important;
		opacity: 1;
	}
	.swiper-pagination-bullet-active{
		opacity: 1;
		background-color: #993408 !important;
	}
	.p-3 > li:hover
	{
		color: #993408 !important;		
	}
	.footer-logo
		{
			text-align: right !important;
		}
	@media (max-width:2048px) {
	  .swiper-container {
	    width: 100%;
	    height: 340px;
		}
	}
	@media (max-width:1024px) {
	  .swiper-container {
	    width: 100%;
	    height: 284px;
		}
		
	}
	@media (max-width: 768px)
	{
		.swiper-container {
	    width: 100%;
	    height: 209px;
		}
		.swiper-slide {
	    padding-top: 105px;
		}
		.navbar-nav {
			display: block;
			}
		

	}
	@media (max-width: 425px)
	{
		.swiper-container {
	    width: 100%;
    	height: 117px;
    	}
		.swiper-slide {
   		 padding-top: 62px !important;
		}
		.swiper-pagination
		{
			padding-top: 10% !important;
		}
		.img-container-body{
		border-left: 1px solid #949599;
		}
		.text-right
		{
			text-align: center !important;
		}
		.footer-logo
		{
			text-align: center !important;
		}
	}
	@media (max-width: 375px)
	{
		.swiper-container {
	    width: 100%;
    	height: 101px;
    	}
		.swiper-slide {
   		 padding-top: 95px !important;
		}
		.swiper-pagination
		{
			padding-top: 10% !important;
		}
		.footer-logo
		{
			text-align: center !important;
		}
	}
	@media (max-width: 375px)
	{
		.swiper-container {
	    width: 100%;
    	height: 85px;
    	}
		.swiper-slide {
   		 padding-top: 117px !important;
		}
		.swiper-pagination
		{
			padding-top: 10% !important;
		}
	}	

</style>
<body>
	<!--Header menu start -->
	<header>
			<div class="container">
			  
			<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-image:url('Slices/header-bg.jpg')">
				  <a class="navbar-brand" href="#"><img src="Slices/logo.png" style="height:50px;"></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  			</button>
				  <div class="collapse navbar-collapse" id="navbarNavDropdown">
				    <ul class="navbar-nav ml-auto">
				      <li class="nav-item black">
				        <a class="nav-link active" href="#">Home</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">News</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Gallery</a>
				      </li>
				      	<li class="nav-item">
				        <a class="nav-link active" href="#">Pages</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Layouts</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Features</a>
				      </li>
				      	<li class="nav-item">
				        <a class="nav-link active" href="#">Blog</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Contact</a>
				      </li>
				    </ul>
				  </div>
				</nav>
			</div>		
	</header>
	<!--Header menu end-->

	<!--Slider image start -->
	
	
	<!--Footer end -->
	<script src="assets/swiper-bundle.min.js"></script>
<script>
		var swiper = new Swiper('.swiper-container', {
      direction: 'vertical',
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
  	 	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-top',
  	},
    });
	</script>
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>
</html>