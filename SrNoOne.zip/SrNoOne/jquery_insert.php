
					
<!DOCTYPE html>
<html>
<head>
	<title>Insert Using JQuery in PHP</title>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity=
	"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	<script>
		$(document).ready(function(){
		  $("#addMNField").click(function(){
		
		  	$("#mn").append("<div class='row'><div class='col-sm-3'></div><div class='col-sm-2'>Mobile Number : </div><div class='col-sm-3'><input type='number' class='form-control' name='mobile[]'/><br></div><div class='col-sm-1'></div><div class='col-sm-3'></div></div>");

		  });
		   $("#addEmailField").click(function(){
		
		  	$("#em").append("<div class='row'><div class='col-sm-3'></div><div class='col-sm-2'>Email : </div><div class='col-sm-3'><input type='email' class='form-control' name='email[]'/><br></div><div class='col-sm-1'></div><div class='col-sm-3'></div></div>");

		  });
		  $("#register").click(function(){
		  	
		  	var name = $("input[name='num']").val();
		  	alert(name);
		  	var m = $("input[name='mobile[]']")
              .map(function(){return $(this).val();}).get();
		  	alert(m);
		  	var e = $("input[name='email[]']")
              .map(function(){return $(this).val();}).get();
		  	alert(e);
		  	

		  	$.ajax({	
		  		url:'insertData.php',
		  		method:'POST',
		  		data:{
		  			name : name,
		  			mobiles : m,
		  			emails : e
		  		},
		  		success : function(data){
		  			alert("done");

		  			alert(data);
		  		}
		  	});
		
		  });
		});
	</script>
</head>
<body>
		<div class="row">
			<div class="col-sm-12">
				<h4>Jquery</h4>
	
				<h5>Insert using Jquery</h5>
				<ol>
					<li>Create HTML form which append fields using jQuery and save in database using PHP+MySQL. (Use Bootstrap for Design)<br></li>
				</ol>	
			</div>
		</div>
		<form method="post"  action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
		<div class="row">
			<div class="col-sm-3"></div>
			<div class="col-sm-2">
			
				Name : 
			</div>
			<div class="col-sm-4">
				<input type="text" class="form-control" name="num" required="required" /><br>
			</div>
			<div class="col-sm-3"></div>
		</div>

		<div class="row">
			<div class="col-sm-3"></div>
			<div class="col-sm-2">
			
				Mobile Number : 
			</div>
			<div class="col-sm-3">
				<input type="number" class="form-control" name="mobile[]" required="required"/><br>
        
			</div>
			<div class="col-sm-1">
				<a><i class="fas fa-plus" style="padding-top: 12px;" id="addMNField"></i> </a>
			</div>
			<div class="col-sm-3"></div>
		</div>
		<p id="mn"></p>
		<div class="row">
			<div class="col-sm-3"></div>
			<div class="col-sm-2">
			
				Email : 
			</div>
			<div class="col-sm-3">
				<input type="email" class="form-control" name="email[]" required="required"/><br>
        
			</div>
			<div class="col-sm-1">
				<a><i class="fas fa-plus" style="padding-top: 12px;" id="addEmailField"></i> </a>
			</div>
			<div class="col-sm-3"></div>
		</div>
		<p id="em"></p>
		<div class="row">
			<div class="col-sm-3"></div>
			<div class="col-sm-2">
			
				<button  class="btn btn-primary" id="register">Insert</button>				
			</div>
			<div class="col-sm-4">
				
			</div>
			<div class="col-sm-3"></div>
		</div>

		</form>
			
			
			
			

		</ol>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>
</html>
 