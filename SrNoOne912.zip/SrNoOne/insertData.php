<?php

$con = mysqli_connect("localhost","root","","db_sanmukh_test");

$name = $_POST['name'];
$phones = $_POST['phones'];
$emails = $_POST['emails'];

$query = "INSERT INTO stud_details(name,phones,emails) VALUES ('$name','$phones','$emails');";

mysqli_query($con,$query);
echo "true";
?>