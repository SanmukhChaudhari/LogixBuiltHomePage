
					
<!DOCTYPE html>
<html>
<head>
	<title>Biggest Number From Array in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Find Biggest Number From Array</h4>
		<ol>
			<li>Write a Program for finding the biggest number in 
an array without using any array functions.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter Numbers(Separated By ,[Comma]) : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Largest</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						printArray($num);
						
					}
					function printArray($num)
					{
						
						$a = array();
						$k=0;

						$a = explode(',', $num);
						echo "Your Array Is : ";print_r($a);
						echo "<br>";
						$max = $a[0]; 
						for($i=0;$i<count($a);$i++)
						{
							if($a[$i] > $max)
							{
								$max = $a[$i];
							}
						}
						echo "Biggest Number is : ".$max;
						
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 