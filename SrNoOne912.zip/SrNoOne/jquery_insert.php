<!DOCTYPE html>
<html>
<head>
	<title>Insert Using JQuery in PHP</title>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
	<script>
		$( document ).ready(function() {
		$('.btn-add-phone').click(function(){
				var name = $("#name").val();
				var index = $('.phone-input').length + 1;
				var pos = index -1;
				var current = $('#phone'+pos+'').val();
				
				if(current){
					$('.phone-list').append(''+
						'<div class="input-group phone-input">'+
							
							'<input type="text" id="phone'+index+'" class="form-control" placeholder="" required="required" />'+
							'<span class="input-group-btn">'+
								'<button class="btn btn-danger btn-remove-phone" type="button"><span class="glyphicon glyphicon-remove"></span></button>'+
							'</span>'+
						'</div>'
					);

				}
				else
				{
					alert("You cannot add field bcoz of null field!");
				}
				
			});
		$('.btn-add-email').click(function(){
				var name = $("#name").val();
				var index = $('.email-input').length + 1;
				var pos = index -1;
				var current = $('#email'+pos+'').val();
				
				
				if(current){
					$('.email-list').append(''+
						'<div class="input-group email-input">'+
							
							'<input type="text" id="email'+index+'" class="form-control" placeholder="" required="required" />'+
							'<span class="input-group-btn">'+
								'<button class="btn btn-danger btn-remove-email" type="button"><span class="glyphicon glyphicon-remove"></span></button>'+
							'</span>'+
						'</div>'
					);

				}
				else
				{
					alert("You cannot add field bcoz of null field!");
				}
				
			});
		$('.btn-insert').click(function(){
				var name = $("#name").val();
				var index = $('.phone-input').length + 1;
				var emailindex = $('.email-input').length + 1;
				var emails = "";
				var phones = "";
				for (var i = 1;i<index ;i++) {
					var current = $('#phone'+i+'').val();
					phones+=current+",";
						
				}

				for (var i = 1;i<emailindex ;i++) {
					var current = $('#email'+i+'').val();
					emails+=current+",";
						
				}
				var res = phones.substring(0, phones.length - 1);
				var emailres = emails.substring(0, emails.length - 1);
				
				$.ajax({
			        type: "POST",
			        url: "insertData.php",			   
			        data: {
			            name: name,
			            phones: res,	
			            emails : emailres		        
			        },
			        success: function(response) {
			            if(response){console.log(response);}else{console.log("Error");}
			        },
			        error: function(response) {
			            console.log(response);
			        }
			    });
				
			
			});
		$(document.body).on('click', '.btn-remove-phone' ,function(){
				$(this).closest('.phone-input').remove();
			});
		$(document.body).on('click', '.btn-remove-email' ,function(){
				$(this).closest('.email-input').remove();
			});

			
	});
		
	
	</script>
</head>
<body>
	<style type="text/css">
		.phone-input{
	margin-bottom:8px;
}
.email-input{
	margin-bottom:8px;
}
	</style>
	<br>	
	<div class="container">


	<form class="form-horizontal" style="max-width:450px;">
		<div class="form-group">
			<label class="col-sm-2 control-label">Name</label>
			<div class="col-sm-10">
				<input type="text" id="name" class="form-control">
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-2 control-label">Phone</label>
			<div class="col-sm-10">
			
				<div class="phone-list">
				
					<div class="input-group phone-input">
						
						
						<input type="text" id="phone1" class="form-control" placeholder="" required="required" />
					</div>
					
				</div>
				
				<br>		
				<button type="button" class="btn btn-success btn-sm btn-add-phone"><span class="glyphicon glyphicon-plus"></span> Add Phone</button>

				
			</div>
			
		</div>
		<div class="form-group">
			<label class="col-sm-2 control-label">Email</label>
			<div class="col-sm-10">
			
				<div class="email-list">
				
					<div class="input-group email-input">
						
						
						<input type="email" id="email1" class="form-control" placeholder="" required="required" />
					</div>
					
				</div>
				
				<br>		
				<button type="button" class="btn btn-success btn-sm btn-add-email"><span class="glyphicon glyphicon-plus"></span> Add Email</button>

				<br>	<br>	
				<button type="button" class="btn btn-success btn-sm btn-insert">Insert Data</button>
			</div>
			
		</div>
		
	</form>
    <hr>
    <small class="text-muted">Working on Bootstrap 3.x.x and up.</small>
</div>
		</body>
</html>
 