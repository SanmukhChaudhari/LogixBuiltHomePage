
					
<!DOCTYPE html>
<html>
<head>
	<title>Fibonacci Series in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Fibonacci Series</h4>
		<ol>
			<li>Write a program in PHP to print Fibonacci series . 
0, 1, 1, 2, 3, 5, 8, 13, 21, 34.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter n : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Result</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						
						getResult($num);
					}
					function getResult($num)
					{
						$a=0;
						$b=1;
						$op = "";
						$op .= $a.", ";
						while($num!=1)
						{
							$ans = $a + $b;
							$b=$a;
							$a = $ans;
							$op .= $ans.", ";
							$num = $num - 1;
						}
						echo $op;
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 