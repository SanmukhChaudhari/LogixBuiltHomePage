<!DOCTYPE html>
<html>
<head>
	<title>Index Page By Sanmukh Chaudhari</title>
</head>
<body>
		<h3>Sr No 1 : Study Basic PHP & MySQL</h3>

		<ol>
			<li><a href="array_string_functions.php">30 PHP functions with small demo for each like array & string functions.</a></li><br>
			<li><a href="sql_functions.php">30 MySQL functions with small demo for each like sum, count with demo.</a></li><br>
			<li><a href="mysql_joins.php">Study Primary, Foreign & Unique + MySQL JOINs with demo.</a></li><br>
		</ol>

		<h3>Sr No 2 : Core PHP</h3>
		<ol>
			<li><a href="basic_patterns.php">Patterns</a></li><br>
			<li>PHP And JS<br><br>
				<ol>
				<li><a href="php_arrays.php">PHP Array & Object</a></li><br>
				<li><a href="js_arrays.php">JS Array & Object</a></li>
				</ol>
			</li><br>
			<li>Basic Programs - 1 in PHP<br><br>
				<ol>
				<li><a href="ternary_operator.php">Write a PHP function to test whether a number is 
greater than 30, 20 or 10 using ternary operator.</a></li><br>
				<li><a href="sum_of_digits.php">Write a PHP program to compute the sum of the 
digits of a number.</a></li><br>
				<li><a href="fibonacci_series.php">Write a program in PHP to print Fibonacci series . 
0, 1, 1, 2, 3, 5, 8, 13, 21, 34.</a></li><br>
				</ol>
			</li>
			<li>Basic Programs - 2 in PHP<br><br>
				<ol>
				<li><a href="reverse_number.php">Write a program to print Reverse of any number</a></li><br>
				<li><a href="prime_or_not.php">To check whether a number is Prime or not.</a></li><br>
				<li><a href="check_leap_year.php">Program to find whether a year is LEAP year or not.</a></li><br>
				</ol>
			</li>
			<li>Basic Programs - 3 in PHP<br><br>
				<ol>
				<li><a href="table_of_number.php">Write a program to find table of a number.</a></li><br>
				<li><a href="biggest_number_from_array.php">Write a Program for finding the biggest number in 
an array without using any array functions.</a></li><br>
				<li><a href="smallest_number_from_array.php">Write a Program for finding the smallest number 
in an array</a></li><br>
				</ol>
			</li>
			<li>Basic JQuery And JS Programs<br><br>
				<ol>
				<li><a href="js_ternary_operator.php">Write a jQuery / JavaScript function to test whether
a number is greater than 30, 20 or 10 using ternary operator.</a></li><br>
				<li><a href="js_fibonacci_series.php">Write a program in jQuery / JavaScript to print
Fibonacci series. 0, 1, 1, 2, 3, 5, 8, 13, 21, 34.</a></li><br>
				
				</ol>
			</li>
			<li>Design (JS / CSS)<br><br>
				<ol>
				<li><a href="home_page_with_bs1.php">Create home page with bootstrap.</a></li><br>
				<li><a href="home_page_with_css.php">Create home page without bootstrap, with CSS using media query.</a></li><br>
				
				</ol>
			</li>
			<li>JQuery<br><br>
				<ol>
				<li><a href="jquery_insert.php">Create HTML form which append fields using jQuery and save in database using PHP+MySQL. (Use Bootstrap for Design)</a></li><br>
				
				
				</ol>
			</li>
		</ol>
		

		


</body>
</html>