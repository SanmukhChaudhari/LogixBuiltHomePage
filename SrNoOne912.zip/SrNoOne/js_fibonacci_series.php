<!DOCTYPE html>
<html>
<head>
	<title>Fibonacci Series in JS</title>
</head>
<body>
		<script>
		function myFunction(p1) {
			var a = 0;
			var b = 1;
			var op = "0, ";
			var ans = 0;
			for(var i =0;i<p1-1;i++)
			{
				ans = a + b;
				b = a;
				a = ans;
				op += ans + ", ";
			}
		  document.getElementById("demo").innerHTML = op;
		  return false;
		}
		
		</script>
		<h3>Core PHP</h3>
	
		<h4>Fibonacci Series in JS</h4>
		<ol>
			<li>Write a program in jQuery / JavaScript to print Fibonacci series. 0, 1, 1, 2, 3, 5, 8, 13, 21, 34.<br></li>

			<form action="#" autocomplete="off" onsubmit="return myFunction(num.value)"><br>
				Enter n : 
				<input type="text" name="num"/><br>
				<br>
				<button >Find Result</button><br><br>
			</form>Output : 
			<p id="demo">
				
				
				
			</p>
			Code : <br><br>
			&ltscript&gt<br>
		function myFunction(p1) {<br>
		var a = 0;<br>
			var b = 1;<br>
			var op = "0, ";<br>
			var ans = 0;<br>
			for(var i =0;i&ltp1-1;i++)<br>
			{<br>
				ans = a + b;<br>
				b = a;<br>
				a = ans;<br>
				op += ans + ", ";<br>
			}<br>
		  document.getElementById("demo").innerHTML = op;<br>
		 
		  return false;<br>
		}<br>
		
		&ltscript&gt<br><br>

		&ltform action="#" autocomplete="off" onsubmit="return myFunction(num.value)"&gt&ltbr&gt<br>
				Enter n : <br>
				&ltinput type="text" name="num"/>&ltbr><br>
				&ltbr><br>
				&ltbutton >Find Result&lt/button>&ltbr>&ltbr><br>
			&lt/form&gt<br>

			
			
			

		</ol>


</body>
</html>
 