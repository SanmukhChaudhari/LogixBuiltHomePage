
					
<!DOCTYPE html>
<html>
<head>
	<title>Check Leap Year or Not in PHP</title>
</head>
<body>	
		<h3>Core PHP</h3>
	
		<h4>Check Leap Year or Not</h4>
		<ol>
			<li>Program to find whether a year is LEAP year or not.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter Number : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Result</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						isPrime($num);
						
					}
					function isPrime($num)
					{
						if ($num % 4 == 0) 
	     				{  
							echo "$num is Leap Year.";
						}
						else
						{
							echo "$num is not a Leap Year.";
						}
	
					
						
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 