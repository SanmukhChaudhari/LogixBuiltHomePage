<?php
include "database.php";

$query = "SELECT * FROM orders";
$orders = mysqli_query($con,$query);

$query = "SELECT * FROM customers";
$customers = mysqli_query($con,$query);

?>
<!DOCTYPE html>
<html>
<head>
	<title>MySql Joins</title>
</head>
<body>
	<h3>Study Primary, Foreign & Unique + MySQL JOINs with demo.</h3>
	Following tables used in the example : 
	<br><br>
	Customers : <br><br>
	<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Name</th>
			<th>Marks</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($customers))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['city']; ?></td>
		</tr>
	<?php }
	?>

	</table>
	<br><br>
	Orders : <br><br>
	<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Customer Id</th>
			<th>Order Price</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($orders))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['cust_id']; ?></td>
			<td><?php echo $row['price']; ?></td>
		</tr>
	<?php }
	?>

	</table>

	

	<ol>

		<li>Inner Join : A INNER JOIN clause is used to combine rows from two or more tables, based on a related column between them.</li>
		<br>
		Input : SELECT Orders.id, Customers.name, Orders.price
		FROM Orders INNER JOIN Customers ON Orders.cust_id=Customers.id;
		<br>
		<br>Output:
		<?php

		$query = "SELECT Orders.id, Customers.name, Orders.price
		FROM Orders INNER JOIN Customers ON Orders.cust_id=Customers.id;";
		$joindetails = mysqli_query($con,$query);
		?>
		<br><br>
		<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Name</th>
			<th>Order Price</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($joindetails))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['price']; ?></td>
		</tr>
	<?php }
	?>

	</table>
<br>

	<li>Left Join : The LEFT JOIN keyword returns all records from the left table (table1), and the matched records from the right table (table2). The result is NULL from the right side, if there is no match.</li>
<br>
		Input : SELECT Orders.id, Customers.name, Orders.price
		FROM  Customers LEFT JOIN Orders ON Orders.cust_id=Customers.id;
		<br>
		<br>Output:
		
<?php

		$query = "SELECT Orders.id, Customers.name, Orders.price
		FROM  Customers LEFT JOIN Orders ON Orders.cust_id=Customers.id;";
		$joindetails = mysqli_query($con,$query);
		?>
		<br><br>
		<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Name</th>
			<th>Order Price</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($joindetails))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['price']; ?></td>
		</tr>
	<?php }
	?>

	</table>



<br>

	<li>Right Join : The RIGHT JOIN keyword returns all records from the right table (table2), and the matched records from the left table (table1). The result is NULL from the left side, when there is no match.</li>

<br>
		Input : SELECT Orders.id, Customers.name, Orders.price
		FROM  Orders RIGHT JOIN  Customers ON Orders.cust_id=Customers.id;
		<br>
		<br>Output:
		
<?php

		$query = "SELECT Orders.id, Customers.name, Orders.price
		FROM  Orders RIGHT JOIN  Customers ON Orders.cust_id=Customers.id;";
		$joindetails = mysqli_query($con,$query);
		?>
		<br><br>
		<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Name</th>
			<th>Order Price</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($joindetails))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['price']; ?></td>
		</tr>
	<?php }
	?>

	</table>

	<br>

	<li>Self Join : A self JOIN is a regular join, but the table is joined with itself.</li>

<br>
		Input : SELECT Orders.id, Customers.name, Orders.price FROM  Orders,Customers WHERE Orders.cust_id < > Customers.id;
		<br>
		<br>Output:
		
<?php

	$query = "SELECT Orders.id, Customers.name, Orders.price FROM  Orders,Customers WHERE Orders.cust_id<>Customers.id";
		$joindetails = mysqli_query($con,$query);
		?>
		<br><br>
		<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Name</th>
			<th>Order Price</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($joindetails))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['price']; ?></td>
		</tr>
	<?php }
	?>

	</table>

	<br>

	<li>Cross Join : A cross JOIN clause returns the Cartesian product of rows from the joined tables.</li>

<br>SELECT customers.name, orders.price FROM customers CROSS JOIN orders;
		<br>
		<br>Output:
		
<?php

	$query = "SELECT customers.name, orders.price FROM customers CROSS JOIN orders";

		$joindetails = mysqli_query($con,$query);
		
		?>
		<br><br>
		<table border="1px solid black" cellpadding="3px" cellspacing="3px">
		<tr>

			<th>Sr No</th>
			<th>Name</th>
			<th>Order Price</th>
		</tr>
	<?php
	$srno = 1;
	
	while($row = mysqli_fetch_assoc($joindetails))
	{
		?>
		<tr >
			<td><?php echo $srno++ ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['price']; ?></td>
		</tr>
	<?php }
	?>

	</table>







	</ol>

</body>
</html>