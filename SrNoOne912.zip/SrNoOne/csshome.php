<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Home Page | Bootstrap</title>
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>
<style type="text/css">
	.container{width: 80%;margin-left: 10%;margin-right: 10%;}
	.bg-light {background-color: #f8f9fa!important;}
	.menu{list-style: none;flex-direction: row;}
	body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
}

.topnav a {
  float: left;
  display: block;
  color: #000;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}
.hide
{
	display: none;
}
.res{
	float: right;margin-top: 10px;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
<body>
	<!--Header menu start -->
	<header>
			<div class="container" style="border:2px solid green;background-image: url(Slices/header-bg.jpg);">
			 	<div class="logo">
			 		<img src="Slices/logo.png" style="height: 50px;margin-top: 10px;">
			 	
			 	</div> 
			 	<div class="topnav" id="myTopnav">
			 			<a href="#">Menu1</a>
			 			<a href="#">Menu1</a>
			 			<a href="#">Menu1</a>
			 			<a href="#">Menu1</a>
			 			<a href="#">Menu1</a>
			 			<a href="#">Menu1</a>
			 			<a href="javascript:void(0);" class="icon" onclick="myFunction()">
    					<i class="fa fa-bars"></i>
  						</a>
			 	</div>
			</div>		
	</header>
	<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>