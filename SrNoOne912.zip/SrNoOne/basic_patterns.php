<!DOCTYPE html>
<html>
<head>
	<title>Patterns in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Patterns</h4>
		<ol>
			<li>Write a php script to print following pattern.<br></li>
			<?php
			for ($i=0; $i < 5; $i++) { 
				for ($j=0; $j <= $i; $j++) { 
					echo "*","&nbsp";
				}
				echo "<br>";
			}
			?>
			Code :<br><br>

			for ($i=0; $i < 5; $i++) { <br>
				for ($j=0; $j <= $i; $j++) { <br>
					echo "*";<br>
				}<br>
				echo "&ltbr&gt";
			}
			<br> <br>

			<li>Write a php script to print following pattern.<br></li>
			<?php
			for ($i=0; $i < 5; $i++) { 
				for ($j=5; $j >$i; $j--) { 
					echo "*","&nbsp";
				}
				echo "<br>";
			}
			?>
			Code :<br><br>

			for ($i=0; $i < 5; $i++) { <br>
				for ($j=5; $j >$i; $j--) { <br>
					echo "*";<br>
				}<br>
				echo "&ltbr&gt";
			}
			<br> <br>


			<li>Write a php script to print following pattern.<br></li>
			<?php
			for ($i=0; $i < 5; $i++) { 
				for ($j=0; $j <= $i; $j++) { 
					echo $i+1,"&nbsp";
				}
				echo "<br>";
			}
			?>
			Code :<br><br>

			for ($i=0; $i < 5; $i++) { <br>
				for ($j=0; $j <= $i; $j++) {<br> 
					echo $i+1;
				}<br>
				echo "&ltbr&gt";
			}
			<br> <br>

			<li>Write a php script to print following pattern.<br></li>
			<?php
			$k =1;
			for ($i=0; $i < 5; $i++) { 
				for ($j=0; $j < $i; $j++) { 
					echo $k++."&nbsp";
				}
				echo "<br>";
			}
			?>
			Code :<br><br>
			$k=1;
			for ($i=0; $i < 5; $i++) { <br>
				for ($j=0; $j < $i; $j++) {<br> 
					echo $k++;
				}<br>
				echo "&ltbr&gt";
			}
			<br> <br>
			
		
			

			<li>Write a php script to print following pattern.<br></li>
			<?php 
				
			  for ($i = 1; $i <= 4; ++$i) {
			  	$k = 0;
      			for ($space = 1; $space <= 4 - $i; ++$space) {
       				  echo "&nbsp&nbsp";
     			 }
     			 while ($k != (2*$i-1)) {
       				  echo "*&nbsp";
       				  ++$k;
   				   }
 			     	echo "<br>";
   				}	
			

			?>
			Code :<br><br>
			for ($i = 1; $i <= 4; ++$i) {<br>
			  	$k = 0;<br>
      			for ($space = 1; $space <= 4 - $i; ++$space) {<br>
       				  echo "&nbsp&nbsp";<br>
     			 }<br>
     			 while ($k != (2*$i-1)) {<br>
       				  echo "*&nbsp";<br>
       				  ++$k;<br>
				}<br>
				echo "&ltbr&gt";<br>
			}
			<br> <br>

			<li>Write a php script to print following pattern.<br></li>
			<?php 
			

				for($i=1;$i<=4;$i++)    
				{    
				for($j=1;$j<=4-$i;$j++)    
				{    
					echo "&nbsp&nbsp";    
				}    
				for($k=1;$k<=$i;$k++)    
				{    
					echo $k,"&nbsp";
				}    
				for($l=$i-1;$l>=1;$l--)    
				{    
					echo $l,"&nbsp";    
				}    
				echo "<br>";    
				} 

			?>
			Code :<br><br>
			for($i=1;$i<=4;$i++)    <br>
				{    <br>
				for($j=1;$j<=4-$i;$j++)    <br>
				{    <br>
					echo "&nbsp&nbsp";    <br>
				}    <br>
				for($k=1;$k<=$i;$k++)    <br>
				{    <br>
					echo $k,"&nbsp";<br>
				}    <br>
				for($l=$i-1;$l>=1;$l--)    <br>
				{    <br>
					echo $l,"&nbsp"; <br>
				}<br>
				echo "&ltbr&gt";<br>
			}
			<br> <br>

		</ol>


</body>
</html>
 