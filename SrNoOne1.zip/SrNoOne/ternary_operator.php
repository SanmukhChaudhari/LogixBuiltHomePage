
					
<!DOCTYPE html>
<html>
<head>
	<title>Ternary Operator in PHP</title>
</head>
<body>
		<h3>Core PHP</h3>
	
		<h4>Ternary Operator</h4>
		<ol>
			<li>Write a PHP function to test whether a number is greater than 30, 20 or 10 using ternary operator.<br></li>

			<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>"><br>
				Enter Number : 
				<input type="text" name="num"/><br>
				<br>
				<button type="submit" name="btnFindResult">Find Result</button><br><br>
			</form>
			<p id="demo">
				Output : <br><br>
				<?php
					if(isset($_POST['btnFindResult']))
					{
						$num = $_POST['num'];
						
						getResult($num);
					}
					function getResult($num)
					{
						$num > 10 ? $n=3 : $m=0; 
						$num > 20 ? $n=2 : $m=0;
						$num > 30 ? $n=1 : $m=0;
						if($n == 3) {echo "Number is > 10";}  
						if($n == 2) {echo "Number is > 20";}  
						if($n == 1) {echo "Number is > 30";}  
					}
					
				?>
				
			</p>
			
			
			

		</ol>


</body>
</html>
 