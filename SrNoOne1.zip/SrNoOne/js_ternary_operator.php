<!DOCTYPE html>
<html>
<head>
	<title>Ternary Operator in JS</title>
</head>
<body>
		<script>
		function myFunction(p1) {
		  if(p1>10){document.getElementById("demo").innerHTML = ">10";}
		  if(p1>20){document.getElementById("demo").innerHTML = ">20";}
		  if(p1>30){document.getElementById("demo").innerHTML = ">30";}
		  if(p1<10) {document.getElementById("demo").innerHTML = "<10";}

		  return false;
		}
		
		</script>
		<h3>Core PHP</h3>
	
		<h4>Ternary Operator in JS</h4>
		<ol>
			<li>Write a Jquery / JS function to test whether a number is greater than 30, 20 or 10 using ternary operator.<br></li>

			<form action="#" autocomplete="off" onsubmit="return myFunction(num.value)"><br>
				Enter Number : 
				<input type="text" name="num"/><br>
				<br>
				<button >Find Result</button><br><br>
			</form>Output : 
			<p id="demo">
				
				
				
			</p>
			Code : <br><br>
			&ltscript&gt<br>
		function myFunction(p1) {<br>
		  if(p1>10){document.getElementById("demo").innerHTML = ">10";}<br>
		  if(p1>20){document.getElementById("demo").innerHTML = ">20";}<br>
		  if(p1>30){document.getElementById("demo").innerHTML = ">30";}<br>
		  if(p1<10) {document.getElementById("demo").innerHTML = "<10";}<br>

		  return false;<br>
		}<br>
		
		&ltscript&gt<br><br>

		&ltform action="#" autocomplete="off" onsubmit="return myFunction(num.value)"&gt&ltbr&gt<br>
				Enter Number : <br>
				&ltinput type="text" name="num"/>&ltbr><br>
				&ltbr><br>
				&ltbutton >Find Result&lt/button>&ltbr>&ltbr><br>
			&lt/form&gt<br>

			
			
			

		</ol>


</body>
</html>
 