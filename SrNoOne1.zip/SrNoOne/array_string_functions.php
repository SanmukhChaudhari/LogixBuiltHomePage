<!DOCTYPE html>
<html>
<head>
	<title>Array & String Functions's Demo</title>
</head>
<body>
		<h3>30 PHP functions with small demo for each like array & string functions.</h3>
	
		<h4>Array Functions</h4>
		<ol>
			<li>array() : </li>
			<br>
			It is use to create an array.
			
			<br>
			<br>
			Input : <br>

		
				$names = array("ABC","DEF","GHI");
				<br>echo gettype($names);
		
			<br>
			<br>

			Output : <br>
			<?php 
				$names = array("ABC","DEF","GHI");
				echo gettype($names); ?>



			<li>array_chunk() : </li>
			<br>
			It is use to split the array.
			
			<br>
			<br>
			Input : <br>

				$cars=array("Volvo","BMW","Toyota","Honda");<br>
				print_r(array_chunk($cars,2));

		
			<br>
			<br>

			Output : <br>
			<?php
			$cars=array("Volvo","BMW","Toyota","Honda");
			print_r(array_chunk($cars,2));
			?>

			<li>array_column() : </li>
			<br>
			It is use to access the column of the array.
			
			<br>
			<br>
			Input : <br>
			$a = array(
  				array(
  				  'id' => 1,
    				'name' => 'Sanmukh'
  					),
				  array(
				    'id' => 2,
				    'name' => 'Ayush'
				  )
				);
				<br>
				$name = array_column($a, 'name');
				<br>print_r($name);
						
			<br>
			<br>

			Output : <br>
			<?php
			$a = array(
  				array(
  				  'id' => 1,
    				'name' => 'Sanmukh'
  					),
				  array(
				    'id' => 2,
				    'name' => 'Ayush'
				  )
				);

				$name = array_column($a, 'name');
				print_r($name);
			?>
			<li>array_combine() : </li>
			<br>
			It is use to combine the arrays in key and value pair.
			
			<br>
			<br>
			Input : <br>
			$id = array(1,2,3);<br>
			$name = array("Sanmukh","Pallav","Mohit");<br>
			$ans = array_combine($id,$name);<br>
			print_r($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
			$id = array(1,2,3);
			$name = array("Sanmukh","Pallav","Mohit");
			$ans = array_combine($id,$name);
			print_r($ans);?>



			<li>array_reverse() : </li>
			<br>
			It is use to reverse the array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			$ans = array_reverse($names);<br>
			print_r($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
		
			$names = array("Sanmukh","Pallav","Mohit");
			$ans = array_reverse($names);
			print_r($ans);
			?>

			<li>array_keys() : </li>
			<br>
			It returns the keys of array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("key1"=>"Sanmukh","key2"=>"Pallav","key3"=>"Mohit");<br>
			$ans = array_keys($names);<br>
			print_r($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
	
			$names = array("key1"=>"Sanmukh","key2"=>"Pallav","key3"=>"Mohit");
			$ans = array_keys($names);
			print_r($ans);	?>
		

			<li>count() : </li>
			<br>
			It returns the size of array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			$ans = count($names);<br>
			print($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
	
			$names = array("Sanmukh","Pallav","Mohit");
			$ans = count($names);
			print($ans);	?>

			<li>end() : </li>
			<br>
			It returns the last element of array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			$ans = end($names);<br>
			print($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
	
			$names = array("Sanmukh","Pallav","Mohit");
			$ans = end($names);
			print($ans);	?>

			<li>current() : </li>
			<br>
			It returns the current element of array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			$ans = current($names);<br>
			print($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
	
			$names = array("Sanmukh","Pallav","Mohit");
			$ans = current($names);
			print($ans);	?>

			<li>next() : </li>
			<br>
			It returns the next element of array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			$ans = next($names);<br>
			print($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
	
			$names = array("Sanmukh","Pallav","Mohit");
			$ans = next($names);
			print($ans);	?>

			<li>sort() : </li>
			<br>
			It is use to sort the array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			sort($names);<br>
			$clength=count($names);<br>
			for($x=0;$x<$clength;$x++)
  			{<br>
  				echo $names[$x];<br>
  				echo "&ltbr&gt";<br>
  			}<br>
		
			<br>
		

			Output : <br>
			<?php
	
			$names = array("Sanmukh","Pallav","Mohit");
			sort($names);
			$clength=count($names);
			for($x=0;$x<$clength;$x++)
  			{
  				echo $names[$x];
  				echo "<br>";
  			}?>

  		<li>rsort() : </li>
			<br>
			It is use to sort the array in reverse order.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			rsort($names);<br>
			$clength=count($names);<br>
			for($x=0;$x<$clength;$x++)
  			{<br>
  				echo $names[$x];<br>
  				echo "&ltbr&gt";<br>
  			}<br>
		
			<br>
		

			Output : <br>
			<?php
	
			$names = array("Sanmukh","Pallav","Mohit");
			rsort($names);
			$clength=count($names);
			for($x=0;$x<$clength;$x++)
  			{
  				echo $names[$x];
  				echo "<br>";
  			}?>

  			<li>range() : </li>
			<br>
			It is use to create an array containing elements which are in range.
			
			<br>
			<br>
			Input : <br>
			
			$nums = range(0,5);<br>
			print_r($nums);<br>
			<br>
		

			Output : <br>
			<?php
	
			
			$nums = range(0,5);
			print_r($nums);
			?>

			<li>array_values() : </li>
			<br>
			It returns the values of array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("key1"=>"Sanmukh","key2"=>"Pallav","key3"=>"Mohit");<br>
			$ans = array_values($names);<br>
			print_r($ans);
		
			<br>
			<br>

			Output : <br>
			<?php
	
			$names = array("key1"=>"Sanmukh","key2"=>"Pallav","key3"=>"Mohit");
			$ans = array_values($names);
			print_r($ans);	?>

			<li>array_push() : </li>
			<br>
			It is used to insert the element at the last of the array.
			
			<br>
			<br>
			Input : <br>
			
			$names = array("Sanmukh","Pallav","Mohit");<br>
			array_push($names,"Ayush");<br>
			print_r($names);
		
			<br>
			<br>

			Output : <br>
			<?php
			$names = array("Sanmukh","Pallav","Mohit");
			array_push($names,"Ayush");
			print_r($names);	?>
		
		</ol>	
		<h4>String Functions</h4>
		<ol>
			<li>strlen() : </li>
			<br>
			It is used to find the length of the string.
			
			<br>
			<br>
			Input : <br>
			
			$name = "Sanmukh";<br>
			echo strlen($name);<br>
			
		
			<br>
			<br>

			Output : <br>
			<?php
			$name = "Sanmukh";
			echo strlen($name);
				?>


			<li>strtolower() : </li>
			<br>
			It is used to convert string into lowercase.
			
			<br>
			<br>
			Input : <br>
			
			$name = "Sanmukh";<br>
			echo strtolower($name);<br>
			
		
			<br>
	

			Output : <br>
			<?php
			$name = "Sanmukh";
			echo strtolower($name);
				?>

			<li>strtoupper() : </li>
			<br>
			It is used to convert string into uppercase.
			
			<br>
			<br>
			Input : <br>
			
			$name = "Sanmukh";<br>
			echo strtoupper($name);<br>
			
		
			<br>

			Output : <br>
			<?php
			$name = "Sanmukh";
			echo strtoupper($name);
				?>

			<li>print() : </li>
			<br>
			It is used to print string.
			
			<br>
			<br>
			Input : <br>
			
			$name = "Sanmukh";<br>
			print($name);<br>
			
		
			<br>
	
			Output : <br>
			<?php
			$name = "Sanmukh";
			print($name);
				?>


			<li>strpos() : </li>
			<br>
			It is used to find the word position in the string.
			
			<br>
			<br>
			Input : <br>
			
			$name = "My name is Sanmukh Chaudhari";<br>
			echo strpos($name,"is");<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "My name is Sanmukh Chaudhari";
			echo strpos($name,"is");
				?>

			<li>stripos() : </li>
			<br>
			It is used to find the word position in the string(case-insensitive).
			
			<br>
			<br>
			Input : <br>
			
			$name = "My name is Sanmukh Chaudhari";<br>
			echo stripos($name,"is");<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "My name is Sanmukh Chaudhari";
			echo stripos($name,"is");
				?>

			<li>strrpos() : </li>
			<br>
			It is used to find the word last position in the string.
			
			<br>
			<br>
			Input : <br>
			
			$name = "My name is Sanmukh Chaudhari";<br>
			echo strrpos($name,"is");<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "My name is Sanmukh Chaudhari";
			echo strrpos($name,"is");
				?>

			<li>strchr() : </li>
			<br>
			It returns all character from this position to the end of the string.
			
			<br>
			<br>
			Input : <br>
			
			$name = "My name is Sanmukh Chaudhari";<br>
			echo strchr($name,"is");<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "My name is Sanmukh Chaudhari";
			echo strchr($name,"is");
				?>


			<li>strrchr() : </li>
			<br>
			It returns all character from this position to the end of the string.
			
			<br>
			<br>
			Input : <br>
			
			$name = "My name is Sanmukh Chaudhari";<br>
			echo strichr($name,"is");<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "My name is Sanmukh Chaudhari";
			echo strrchr($name,"is");
				?>

			<li>trim() : </li>
			<br>
			It removes whitespace from the string.
			
			<br>
			<br>
			Input : <br>
			
			$name = "My name is Sanmukh Chaudhari ";<br>
			echo trim($name);<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "My name is Sanmukh Chaudhari ";
			echo trim($name);
				?>

			<li>str_split() : </li>
			<br>
			It splits the string and returns the array of characters.
			
			<br>
			<br>
			Input : <br>
			
			$name = "Sanmukh";<br>
			print_r(str_split($name));<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "Sanmukh";
			print_r(str_split($name));
				?>

			<li>str_word_count() : </li>
			<br>
			It returns the total number of words.
			
			<br>
			<br>
			Input : <br>
			
			$name = "My name is Sanmukh Chaudhari";<br>
			echo str_word_count($name);<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "My name is Sanmukh Chaudhari";
			echo str_word_count($name);
				?>	


			<li>ucwords() : </li>
			<br>
			It converts first character of each word into uppercase.
			
			<br>
			<br>
			Input : <br>
			
			$name = "my name is sanmukh chaudhari";<br>
			echo ucwords($name);<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "my name is sanmukh chaudhari";
			echo ucwords($name);
				?>

			<li>ucfirst() : </li>
			<br>
			It converts first character of string into uppercase.
			
			<br>
			<br>
			Input : <br>
			
			$name = "my name is sanmukh chaudhari";<br>
			echo ucfirst($name);<br>
			
			<br>
		

			Output : <br>
			<?php
			
			$name = "my name is sanmukh chaudhari";
			echo ucfirst($name);
				?>

			<li>strncasecmp() : </li>
			<br>
			It compare two strings(case-insensitive).
			
			<br>
			<br>
			Input : <br>
			
			$a = "S";<br>
			$b = "s";<br>
			echo strncasecmp($a,$b);<br>
			
			<br>
		

			Output : <br>
			<?php
			$a = "S";
			$b = "s";
			echo strncasecmp($a,$b,0);
				?>
		</ol>
</body>
</html>