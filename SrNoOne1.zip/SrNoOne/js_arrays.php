<!DOCTYPE html>
<html>
<head>
	<title>JS Arrays</title>
</head>
<body>
		
		<h3>Core PHP</h3>
	
		<h4>JS Arrays</h4>
		<ol>
			<li>Indexed array : Arrays with a numeric index<br></li>

			Example : <br><br>
			Code : <br>
			var person = ["Sanmukh", "Vignesh", "Ayush"];<br>
			document.getElementById("demo1").innerHTML = person[0];
			<br><br>
			Output : 
			<p id="demo1"></p>

			<br><br>
			

			<li>Indexed array with for loop : <br></li>

			Example : <br><br>
			Code : <br>
			var person = ["Sanmukh", "Vignesh", "Ayush"];<br>
			op = "";<br>
			for(var i =0;i<3;i++)<br>
			{<br>
				op += person[i] + "&ltbr&gt";<br>
			}<br>
			document.getElementById("demo2").innerHTML = op;
			<br><br>
			Output : 
			<p id="demo2"></p>

			<br><br>

			<li>Indexed array with foreach loop : <br></li>

			Example : <br><br>
			Code : <br>
			var person = ["Sanmukh", "Vignesh", "Ayush"];<br>
			op = "";<br>
			person.forEach(getName);<br>
			function getName(name)<br>
			{<br>
				op += name + " : Using ForEach&ltbr&gt";<br>
			}<br>
			document.getElementById("demo3").innerHTML = op;
			<br><br>
			Output : 
			<p id="demo3"></p>

			<br><br>

			<li>Indexed array with while loop : <br></li>

			Example : <br><br>
			Code : <br>
			var person = ["Sanmukh", "Vignesh", "Ayush"];<br>
			op = "";<br>
			i=0;<br>
			while(i&ltperson.length)
			{<br>
				op += person[i] + " : Using While&ltbr&gt";<br>
			}<br>
			document.getElementById("demo4").innerHTML = op;
			<br><br>
			Output : 
			<p id="demo4"></p>

			<br><br>

			<li>Indexed array with do while loop : <br></li>

			Example : <br><br>
			Code : <br>
			var person = ["Sanmukh", "Vignesh", "Ayush"];<br>
			op = "";<br>
			i=0;<br>
			do
			{<br>
				op += person[i] + " : Using Do While&ltbr&gt";<br>
			}<br>
			while(i&ltperson.length);<br>
			document.getElementById("demo5").innerHTML = op;
			<br><br>
			Output : 
			<p id="demo5"></p>

			<li>Object in js : <br></li>

			Example : <br><br>
			Code : <br>

			var person = {name:"Sanmukh",age:20,contact_number:"8154993851",toString(){return this.name+" : "+this.age+" : "+this.contact_number}};<br>
	
			document.getElementById("demo6").innerHTML = person.toString();			<br>
			delete person.contact_number;<br>
			
			document.getElementById("demo7").innerHTML = person.toString();			<br>
			person.contact_number = 8154993851;<br>
		
			document.getElementById("demo8").innerHTML = person.toString();	
			
			<br><br>
			Output : <br><br>

			Object Value Before Delete Contact Number
			<p id="demo6"></p>
			Object Value After Delete Contact Number :
			<p id="demo7"></p>
			Object Value After Contact Number :
			<p id="demo8"></p>


		</ol>
		<script>
			//array
			var person = ["Sanmukh", "Vignesh", "Ayush"];
			document.getElementById("demo1").innerHTML = person[0];
			
			//for loop
			op="";
			for(var i =0;i<3;i++)
			{
				op += person[i] + "<br>";
			}
			document.getElementById("demo2").innerHTML = op;

			//foreach loop
			var person = ["Sanmukh", "Vignesh", "Ayush"];
			op = "";
			person.forEach(getName);
			function getName(name)
			{
				op += name + " : Using ForEach<br>";
			}
			
			document.getElementById("demo3").innerHTML = op;
			
			//while
			var i=0;
			op = "";

			while(i<person.length)
			{
				op += person[i] + " : Using While Loop<br>";
				i++;
			}
			document.getElementById("demo4").innerHTML = op;

			//do while loop
			var i=0;
			op = "";
			do
			{
				op += person[i] + " : Using Do While Loop<br>";
				i++;
			}
			while(i<person.length);
			document.getElementById("demo5").innerHTML = op;


			//objecct 
			var person = {name:"Sanmukh",age:20,contact_number:"8154993851",toString(){return this.name+" : "+this.age+" : "+this.contact_number}};
			document.getElementById("demo6").innerHTML = person.toString();			
			delete person.contact_number;
			
			document.getElementById("demo7").innerHTML = person.toString();			
			person.contact_number = 8154993851;

			document.getElementById("demo8").innerHTML = person.toString();			
		</script>

</body>
</html>
 