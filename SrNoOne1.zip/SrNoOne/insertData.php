<?php

$con = mysqli_connect("localhost","root","","db_sanmukh_test");

$name = $_POST['name'];
$mns = $_POST['mobiles'];
$ems = $_POST['emails'];

$query = "INSERT INTO stud_details(name,mobiles,emails) VALUES ('$name','$mns','$ems');";

mysqli_query($con,$query);
echo "true";
?>