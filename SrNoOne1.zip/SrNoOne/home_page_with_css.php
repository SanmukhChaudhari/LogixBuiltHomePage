<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>Home Page | CSS</title>
	<link rel="stylesheet" href="assets/swiper-bundle.min.css">
	

</head>
<style type="text/css">
	[class*="col-"] {width: 100%;}
	*{box-sizing: border-box;}
	.logoDiv{margin: -0.64% 9.5% 0% 9.5%;}
	.nav-menu > li{margin-top: 13px;margin-left: 10px;float: left;margin-right: 10px;}
	.nav-menu > li a{color:#333;font-size: 15px;font-family: Tohama;text-decoration: none;}
	.nav-menu > li a:hover {color: #993408 !important;}
	.img-container{border: 1px solid #949599;position: relative;}
	.my-row{display:flex;width:100%}
	.container{position:relative}
	.container-fluid{width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;}
	.img-container-body{border-top: 1px solid #949599;border-right: 1px solid #949599;border-bottom: 1px solid #949599;}
	.tab-content {padding: 6px 12px;border: 1px solid #ccc;border-top: none;}
	.tab-pane{}
	.img-heading{margin-top: 5px;font-size: 15px;font-family: Georgia;color:#000;}
	.img-content{font-size: 13px;font-family: Tohama;color:#333;}
	hr{margin-right: 20%;}
	.side-a{padding-top: 10px;padding-bottom: 10px;padding-left: 20px;color:#993408 !important;margin-bottom: 5px !important;margin-top: 5px !important;font-family: Georgia !important;text-decoration: none;}
	.flex-column{display: flex;flex-direction:column!important;}
	.footer-container{padding-top: 15px;padding-left: 7.5%;padding-right: 7.5%;}
	.footer-head{font-family: Tahoma;font-size: 15px;color:#888;margin-right: 10px;}	
	hr{border-top: 2px dashed grey;}
	.footer-img{padding-top:10px !important;padding-bottom: 10px !important;}
	.footer-icons > li {display: flex !important;padding-bottom: 5px;padding-top: 5px;}
	.icon-names{padding-left: 10px !important;}
	.icon-names:hover{padding-left: 10px !important;}
	.first-img-text:hover img{content: url('Slices/logo1.png');}
	.first-img-text:hover .first-p{color:#556fa8;}
	.second-img-text:hover img{content: url('Slices/logo2.png');}
	.second-img-text:hover .second-p{color:#34ccfd;}
	.third-img-text:hover img{content: url('Slices/logo3.png');}
	.third-img-text:hover .third-p{color:#006f9f;}
	.fourth-img-text:hover img{content: url('Slices/logo4.png');}
	.fourth-img-text:hover .fourth-p{color:#ff9b00;}
	.footer-menu > li{margin-right: 10px;}
	.footer-menu > li > a{color: #666 !important;font-style: Tahoma;font-size: 13px; font-weight: bold;}
	.footer-news > li{margin-left: -15px !important;}
	.footer-menu > li > a : hover{color: #993408 !important;		}
	p:hover{color: #993408 !important;			}
	.footer-text{margin-top: -2px !important;color: #999 !important;font-style: Tahoma;font-size: 13px; }
	.top-right {position: absolute;top: 10px;right: 10px;left: 10px;bottom: 10px;}
	.p-3 > li:hover{color: #993408 !important;}
	.p-3{padding: 1rem!important;} 
	.mb-3, .my-3 {margin-bottom: 1rem!important;}
	.p-0 {	padding: 0!important;}
	.slide-content{font-family: Georgia !important;color: #ccc;font-size: 14px;}
	.slide-heading{font-family: Georgia !important;color: #fff;font-size: 24px;}
	.swiper-pagination-bullet{background-color: white !important;opacity: 1;}
	.swiper-pagination-bullet-active{opacity: 1;background-color: #993408 !important;}
	.swiper-container {width: 100%;height: 340px;}
	@media only screen and (min-width: 600px) {
  /* For tablets: */
  .col-s-1 {width: 8.33%;}
  .col-s-2 {width: 16.66%;}
  .col-s-3 {width: 25%;}
  .col-s-4 {width: 33.33%;}
  .col-s-5 {width: 41.66%;}
  .col-s-6 {width: 50%;}
  .col-s-7 {width: 58.33%;}
  .col-s-8 {width: 66.66%;}
  .col-s-9 {width: 75%;}
  .col-s-10 {width: 83.33%;}
  .col-s-11 {width: 91.66%;}
  .col-s-12 {width: 100%;}
}
@media only screen and (min-width: 768px) {
  /* For desktop: */
  .col-1 {width: 8.33%;}
  .col-2 {width: 16.66%;}
  .col-3 {width: 25%;}
  .col-4 {width: 33.33%;}
  .col-5 {width: 41.66%;}
  .col-6 {width: 50%;}
  .col-7 {width: 58.33%;}
  .col-8 {width: 66.66%;}
  .col-9 {width: 75%;}
  .col-10 {width: 83.33%;}
  .col-11 {width: 91.66%;}
  .col-12 {width: 100%;}
}

</style><body>
	<!--Header menu start -->
	<header>
			<div class="container">
			  
			<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-image:url('Slices/header-bg.jpg')">
				  <a class="navbar-brand" href="#"><img src="Slices/logo.png" style="height:50px;"></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  			</button>
				  <div class="collapse navbar-collapse" id="navbarNavDropdown">
				    <ul class="navbar-nav ml-auto">
				      <li class="nav-item black">
				        <a class="nav-link active" href="#">Home</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">News</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Gallery</a>
				      </li>
				      	<li class="nav-item">
				        <a class="nav-link active" href="#">Pages</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Layouts</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Features</a>
				      </li>
				      	<li class="nav-item">
				        <a class="nav-link active" href="#">Blog</a>
				      </li>
				      <li class="nav-item">
				        <a class="nav-link active" href="#">Contact</a>
				      </li>
				    </ul>
				  </div>
				</nav>
			</div>		
	</header>
	<!--Header menu end-->

	<!--Slider image start -->
	
	<div class="container-fluid p-0" style="background-color: #949599;">
		<div class="container" style="padding: 15px white;padding-top: 10px;padding-bottom: 10px;">
			
			<div class="row">
				<div class="col-s-12">
			    	<div class="img-container">
			        	<img src="Slices/Slider_img.jpg" style="border:11px solid white;" class="w-100">
			        	<div class="row top-right" style="position: absolute;">
							<div class="col-s-8">
								
							</div>			     
							<div class="col-s-4">
						
		                        <div class="swiper-container">
							    	<div class="swiper-wrapper" >
							      		<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline1</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side.good aftyernoon This is from my side.This is from my side.This is from my side.   good morning.
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my 
							      				</div>
							      					
							      			</div>
										</div>
										<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline2</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side. good morning.
							      				</div>
							      					
							      			</div>
										</div>
										<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline3</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side. good morning.
							      				</div>
							      					
							      			</div>
										</div>
										<div class="swiper-slide">
							      			
							      			<div style="padding-left: 10px !important;padding-right: 15px !important;">
							      				<div class="slide-heading">Slide Headline4</div>
							      				<div class="slide-content">
							      					Lorem ipsum dolor sit amet,cons adipisong<br>This is from my side.This is from my side.Hello everyone This is from my side.This is from my side. good morning.
							      				</div>
							      					
							      			</div>
										</div>
									
							    	</div>
							    	<div class="swiper-pagination" style="border-left: 1px solid white;padding-top:40%;height:100%;padding-left: 5px;">
							    		
							    	</div>
							    	<div class="swiper-scrollbar"></div>
							  	</div>		
                  			</div>
						</div>  <!--End row--> 		
			       	</div>
				</div>  
			</div>
		</div>
	</div>
			
	<!--Slider image end -->

	<!--Tabs/Pills part start -->
	
	<div class="container my-3 ">
	<div class="row " style="padding-left: 15px;padding-right: 15px;display: flex;">	
			<div class="col col-s-3 img-container p-0" style="background-color: #ebebeb;">
				<nav class="nav nav-pills flex-column" >
			        <a href="#first" class="nav-item  side-a active" data-toggle="tab">
			            FINDINGS
			        </a>

			        <a href="#second" class="nav-item  side-a" data-toggle="tab">
			            PROMOTIONAL ACTIVITIES
			        </a>
			        <a href="#third" class="nav-item  side-a" data-toggle="tab">
			            ENVIRONMENT
			        </a>
			    </nav> 
			</div>

			<div class="col-s-9 img-container-body">
				
				<div class="tab-content ">
					
				<div class="tab-pane active" id="first">

					<div class="row mt-3 mb-3">
						<div class="col-s-4">
							<img src="Slices/img1.jpg" class="w-100">
							<div class="img-heading">
							111Aldus PageMaker including versions of Lorem Ipsum. 
						</div>
						<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>

						</div>
						<div class="col-s-4">
							<img src="Slices/img2.jpg" class="w-100">
							<div class="img-heading">
							Many desktop publishing packages and web pages. 
							</div>
							<div class="img-content">
							It is a long established fact that a reader will be distracted by the readable content.	
							</div>


						</div>
						<div class="col-s-4">
							<img src="Slices/img3.jpg" class="w-100">
							<div class="img-heading">
							Aldus PageMaker including versions of Lorem Ipsum. 
							</div>
							<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="second">

					<div class="row mt-3 mb-3">
						<div class="col-s-4">
							<img src="Slices/img1.jpg" class="w-100">
							<div class="img-heading">
							222Aldus PageMaker including versions of Lorem Ipsum. 
						</div>
						<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>

						</div>
						<div class="col-s-4">
							<img src="Slices/img2.jpg" class="w-100">
							<div class="img-heading">
							Many desktop publishing packages and web pages. 
							</div>
							<div class="img-content">
							It is a long established fact that a reader will be distracted by the readable content.	
							</div>


						</div>
						<div class="col-s-4">
							<img src="Slices/img3.jpg" class="w-100">
							<div class="img-heading">
							Aldus PageMaker including versions of Lorem Ipsum. 
							</div>
							<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="third">

					<div class="row mt-3 mb-3">
						<div class="col-s-4">
							<img src="Slices/img1.jpg" class="w-100">
							<div class="img-heading">
							333Aldus PageMaker including versions of Lorem Ipsum. 
						</div>
						<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>

						</div>
						<div class="col-s-4">
							<img src="Slices/img2.jpg" class="w-100">
							<div class="img-heading">
							Many desktop publishing packages and web pages. 
							</div>
							<div class="img-content">
							It is a long established fact that a reader will be distracted by the readable content.	
							</div>


						</div>
						<div class="col-s-4">
							<img src="Slices/img3.jpg" class="w-100">
							<div class="img-heading">
							Aldus PageMaker including versions of Lorem Ipsum. 
							</div>
							<div class="img-content">Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.
							</div>
						</div>
					</div>
				</div>
			</div>

				
				
			</div>
			


		</div>
	</div>
	<!--Tabs/Pills part end -->

	<!--Footer start-->
	<footer>
		<div class="container-fluid" style="background-color: #f8f8f8;border-top: 1px solid #949599;border-bottom: 1px solid #949599;">
			<div class="container footer-container">
			
					<div class="row">
						<div class="col-lg-3 footer-head"><b>LATEST NEWS</b>
							<hr/>
							<ul class="p-3 footer-news" >
								<li style="display: flex;">
									<div style="margin-right: 10px;">
										<img  src="Slices/sidebar-bullet.jpg">
									</div>
									<div>
										<p>Many desktop publishing packages and web page</p>
									</div>
								</li>
								<li style="display: flex;">
									<div style="margin-right: 10px;">
										<img  src="Slices/sidebar-bullet.jpg">
									</div>
									<div>
										<p>Lorem ipsum dolor sit amet, consectetur adipscing elit. Aenean et sollicitudin risus.</p>
									</div>
								</li>
								<li style="display: flex;">
									<div style="margin-right: 10px;">
										<img  src="Slices/sidebar-bullet.jpg">
									</div>
									<div>
										<p>It is a long established fact that a reader will be distracted by the readable content.</p>
									</div>
								</li>
							</ul>

						</div>
						<div class="col-lg-3 footer-head"><b>RECENT PROJECTS</b>
							<hr/>
							<ul class="p-3" style="list-style: none;padding-left:0px !important;">
								<li><img src="Slices/recent-pro-1.jpg" class="footer-img"></li>
								<li><img src="Slices/recent-pro-2.jpg" class="footer-img"></li>
								<li><img src="Slices/recent-pro-3.jpg" class="footer-img"></li>
							</ul>
						</div>
						<div class="col-lg-3 footer-head"><b>STAY IN TOUCH</b>
							<hr/>
							<ul class="p-3 footer-icons" style="list-style: none;padding-left:0px !important;">
								<li>
									<div class="first-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo5.png" id="f-icon1">
										</div>		
										<div class="icon-names first-p">Facebook
										</div>
									</div>
								</li>
								<li>
									<div class="second-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo6.png" id="f-icon2">
										</div>		
										<div class="icon-names second-p">Twitter
										</div>
									</div>
								</li>
								<li>
									<div class="third-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo7.png" id="f-icon3">
										</div>		
										<div class="icon-names third-p">Linked In
										</div>
									</div>
								</li>
								<li>
									<div class="fourth-img-text" style="display: flex;">
										<div>
											<img src="Slices/logo8.png" id="f-icon4">
										</div>		
										<div class="icon-names fourth-p">RSS
										</div>
									</div>
								</li>
								
							</ul>
						</div>
						<div class="col-lg-3 footer-head"><b>SECURITY & PRIVACY</b>
							<hr/>
							<ul class="p-3" style="list-style: none;padding-left:0px !important;">
								<li>Security</li>
								<li>Privacy Policy</li>
								<li>Terms of Service</li>
							</ul>
						</div>
					</div>		
			</div>
		
		</div>

		<div class="container">
				<div class="row">
					<div class="col-s-6">
						<ul class="navbar-nav ml-auto list-group-horizontal p-1 footer-menu">
					      <li class="nav-item	">
					        <a class="nav-link" href="#">Home</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">News</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Gallery</a>
					      </li>
					      	<li class="nav-item">
					        <a class="nav-link" href="#">Pages</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Layouts</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Features</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Blog</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Contact</a>
					      </li>
						</ul>
						<div class="footer-text" style="float: left;">
						&#169; 2011 rtPanel. All Rights Reserved. Designed by rtCamp.
						</div>

					</div>
					<div class="col-s-6 footer-logo" style="margin-top: 10px;">
							<img src="Slices/footer-logo.png" ;>
						
					</div>
				</div>
			</div>
	</footer>
	<!--Footer end -->
	<script src="assets/swiper-bundle.min.js"></script>
<script>
		var swiper = new Swiper('.swiper-container', {
      direction: 'vertical',
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
  	 	nextEl: '.swiper-button-next',
    	prevEl: '.swiper-button-top',
  	},
    });
	</script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
</body>
</html>